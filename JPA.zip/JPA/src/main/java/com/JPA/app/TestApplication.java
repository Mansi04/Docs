package com.JPA.app;

import com.JPA.dao.ServiceDao;
import com.JPA.model.Places;

public class TestApplication {

	public static void main(String[] args) {
		Places places=new Places();
		places.setLocation("Pune");
		places.setPlaceid(106);
		places.setPname("Dagdusheth Temple");

		boolean flag= new ServiceDao().addPlace(places);
		System.out.println(flag);
		System.exit(0);
		/*places.setPlaceid(101);
		Places p=new ServiceDao().getPlace(places);
		if(p==null)
			System.out.println("Place not found");
		else
			System.out.println(p.getPname());*/
	}

}
