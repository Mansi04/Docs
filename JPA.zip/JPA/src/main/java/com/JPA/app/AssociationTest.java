package com.JPA.app;

import java.util.Date;
import java.util.List;

import com.JPA.dao.ServiceDao;
import com.JPA.model.Booking;
import com.JPA.model.Flight;
import com.JPA.model.Places;

public class AssociationTest {

	public static void main(String[] args) {
		
		Flight flight = new Flight();
		/*flight.setFlightid("F100");
		flight.setAirline("AirIndia");
		flight.setSource("Mum");
		flight.setDestination("Del");
		
		
		Booking b1 = new Booking();
		b1.setBookingdate(new Date());
		//b1.setFlightid("F100");
		b1.setPname("Rahul");
		b1.setPage(25);

		Booking b2 = new Booking();
		b2.setBookingdate(new Date());
		//b2.setFlightid("F100");
		b2.setPname("Nita");
		b2.setPage(45);
		
		flight.getBookinglist().add(b1);
		flight.getBookinglist().add(b2);
		
		boolean flag= new ServiceDao().addFlight(flight);
		System.out.println(flag);*/
		//Flight flight=new Flight();
	
		flight.setFlightid("F100");
		Flight f=new ServiceDao().getFlight(flight);
		if(f!=null){
			System.out.printf("%20s  %20s", f.getSource(),f.getDestination());
			List<Booking> blist= f.getBookinglist();
			for(Booking b:blist)
			{
				System.out.printf("%20s   %20s",b.getPname(),b.getPage());
			}
		}
		else
			System.out.println("Booking not found");
		System.exit(0);
	}

}
