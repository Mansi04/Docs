package com.JPA.dao;
//Code for Persist data using hibernate JPA
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.JPA.model.Flight;
import com.JPA.model.Places;

public class ServiceDao {

	public boolean addPlace(Places places)
	{
		boolean result=false;
		try{
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(places);
			em.getTransaction().commit();
			result=true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return result;
	}

	public Places getPlace(Places places) {
		Places p=null;
		try
		{
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			p=em.find(Places.class, places.getPlaceid());
	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return p;
	}
	
	public Flight getFlight(Flight flight){
		
		Flight f = null;
		try{
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pub");
			EntityManager em = emf.createEntityManager();
			f=em.find(Flight.class, flight.getFlightid());
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return f;
	}

	public boolean addFlight(Flight flight) {

		boolean result=false;
		try{
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pub");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(flight);
			em.getTransaction().commit();
			result=true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return result;
		
	
	}
}
